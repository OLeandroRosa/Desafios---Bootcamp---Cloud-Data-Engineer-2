# Aula07_Calculadora2

Description. 
The package Calculator is used to:
 - soma (parameter 1,parameter 2)
 - substracao (parameter 1,parameter 2)
 - multiplicacao (parameter 1,parameter 2)
 - divisao (parameter 1, parameter 2)

## Usage

```python
from aula07_Calculadora2 import Calculadora
calculadora_var.soma(valor_a, valor_b)
calculadora_var.substracao(valor_a, valor_b)
calculadora_var.multiplicacao(valor_a, valor_b)
calculadora_var.divisao(valor_a, valor_b)
```

## Author
Leandro Rosa

## License
[MIT](https://choosealicense.com/licenses/mit/)